
#include "constants.h"

TeamColor team=UNDEFINED;

const double distance_to_claw = 150;
